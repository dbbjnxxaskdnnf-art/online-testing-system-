import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Check,
  ChevronRight,
  CircleHelp,
  Clock3,
  Compass,
  Crown,
  Flame,
  House,
  Lightbulb,
  Medal,
  RotateCcw,
  Sparkles,
  Trophy,
  UserRound,
  UsersRound,
  X,
  Zap,
} from 'lucide-react';
import {
  Link,
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';
import type { LucideIcon } from 'lucide-react';

type Language = 'ru' | 'en' | 'kk';
type Role = 'student' | 'teacher';
type LocalizedText = Record<Language, string>;
type Category = 'all' | 'personal' | 'geography' | 'culture' | 'science';

type Question = {
  prompt: LocalizedText;
  options: LocalizedText[];
  answer: number;
  fact: LocalizedText;
};

type Quiz = {
  id: string;
  title: LocalizedText;
  description: LocalizedText;
  category: Exclude<Category, 'all'>;
  questions: number;
  minutes: number;
  color: string;
  softColor: string;
  icon: LucideIcon;
  difficulty: LocalizedText;
  questionsData: Question[];
};

type User = {
  id: string;
  name: string;
  email: string;
  password: string;
  role: Role;
};

type QuizResult = {
  id: string;
  userName: string;
  userEmail: string;
  quizId: string;
  quizTitle: LocalizedText;
  score: number;
  total: number;
  percentage: number;
  createdAt: string;
};

type StoredQuiz = Omit<Quiz, 'icon'>;

const languages: Array<{ id: Language; label: string }> = [
  { id: 'ru', label: 'Русский' },
  { id: 'en', label: 'English' },
  { id: 'kk', label: 'Қазақша' },
];

const copy: Record<string, LocalizedText> = {
  headerNote: { ru: 'Быстрый вызов, отличная энергия.', en: 'A quick challenge for a bright mind.', kk: 'Ақылға арналған қысқа сынақ.' },
  home: { ru: 'Главная', en: 'Home', kk: 'Басты бет' },
  teacherResults: { ru: 'Результаты учеников', en: 'Student results', kk: 'Оқушы нәтижелері' },
  signIn: { ru: 'Войти', en: 'Sign in', kk: 'Кіру' },
  register: { ru: 'Регистрация', en: 'Register', kk: 'Тіркелу' },
  logout: { ru: 'Выйти', en: 'Log out', kk: 'Шығу' },
  heroEyebrow: { ru: 'Маленькая победа для мозга', en: 'A small win for your brain', kk: 'Миға арналған шағын жеңіс' },
  heroOne: { ru: 'Будьте', en: 'Stay', kk: 'Қызық' },
  heroTwo: { ru: 'любопытны.', en: 'curious.', kk: 'болыңыз.' },
  heroThree: { ru: 'Поиграйте немного.', en: 'Play a little.', kk: 'Біраз ойнап көріңіз.' },
  heroDescription: { ru: 'Небольшие викторины для пауз между делами. Выберите карточку, доверьтесь интуиции и узнайте ещё что-нибудь интересное.', en: 'Short quizzes for the spaces between things. Pick a card, trust your instincts, and learn something new.', kk: 'Істер арасындағы үзіліске арналған қысқа викториналар. Карточканы таңдап, біліміңізді сынап көріңіз.' },
  roundTime: { ru: 'Раунды по 2–3 минуты', en: '2–3 minute rounds', kk: '2–3 минуттық раундтар' },
  noRegistration: { ru: 'Регистрация нужна только для сохранения результата', en: 'Register to save your result', kk: 'Нәтижені сақтау үшін тіркеліңіз' },
  chooseMood: { ru: 'Выберите настроение', en: 'Choose a mood', kk: 'Көңіл-күйді таңдаңыз' },
  thinkAbout: { ru: 'О чём сегодня думаем?', en: 'What are we thinking about today?', kk: 'Бүгін не туралы ойланамыз?' },
  allQuizzes: { ru: 'Все викторины', en: 'All quizzes', kk: 'Барлық викториналар' },
  forYou: { ru: 'Для вас', en: 'For you', kk: 'Сіз үшін' },
  geography: { ru: 'География', en: 'Geography', kk: 'География' },
  culture: { ru: 'Культура', en: 'Culture', kk: 'Мәдениет' },
  science: { ru: 'Наука', en: 'Science', kk: 'Ғылым' },
  questions: { ru: 'вопросов', en: 'questions', kk: 'сұрақ' },
  start: { ru: 'Начать', en: 'Start', kk: 'Бастау' },
  chooseQuiz: { ru: 'Выберите викторину', en: 'Choose a quiz', kk: 'Викторинаны таңдаңыз' },
  noQuizzes: { ru: 'Эта полка ещё наполняется.', en: 'This shelf is still filling up.', kk: 'Бұл сөре әлі толтырылуда.' },
  noQuizzesHint: { ru: 'Попробуйте другую категорию.', en: 'Try another category.', kk: 'Басқа санатты көріңіз.' },
  backToQuizzes: { ru: 'К викторинам', en: 'Back to quizzes', kk: 'Викториналарға' },
  question: { ru: 'Вопрос', en: 'Question', kk: 'Сұрақ' },
  next: { ru: 'Следующий вопрос', en: 'Next question', kk: 'Келесі сұрақ' },
  seeResult: { ru: 'Узнать результат', en: 'See result', kk: 'Нәтижені көру' },
  excellent: { ru: 'Отлично!', en: 'Excellent!', kk: 'Керемет!' },
  goodTry: { ru: 'Хорошая попытка.', en: 'Good try.', kk: 'Жақсы талпыныс.' },
  timeUp: { ru: 'Время вышло.', en: 'Time is up.', kk: 'Уақыт аяқталды.' },
  roundFinished: { ru: 'Раунд завершён', en: 'Round complete', kk: 'Раунд аяқталды' },
  yourResult: { ru: 'Ваш результат', en: 'Your result', kk: 'Сіздің нәтижеңіз' },
  correct: { ru: 'правильных', en: 'correct', kk: 'дұрыс' },
  playAgain: { ru: 'Сыграть ещё раз', en: 'Play again', kk: 'Қайта ойнау' },
  shortReview: { ru: 'Короткий разбор', en: 'Quick review', kk: 'Қысқаша талдау' },
  resultHigh: { ru: 'У вас удивительно любознательный ум.', en: 'You have a wonderfully curious mind.', kk: 'Сіздің ізденімпаз ойыңыз керемет.' },
  resultMid: { ru: 'Отличное начало — впереди ещё много интересного.', en: 'A great start — there is more to discover.', kk: 'Керемет бастама — алда әлі көп жаңалық бар.' },
  resultLow: { ru: 'Каждый хороший факт начинается с правильной ошибки.', en: 'Every good fact starts with a useful mistake.', kk: 'Әр жақсы білім пайдалы қателіктен басталады.' },
  authTitle: { ru: 'Войдите в Quizly', en: 'Sign in to Quizly', kk: 'Quizly-ге кіріңіз' },
  authSubtitle: { ru: 'Сохраняйте результаты и учитесь в своём ритме.', en: 'Save results and learn at your own pace.', kk: 'Нәтижелерді сақтап, өз қарқыныңызбен үйреніңіз.' },
  createAccount: { ru: 'Создать аккаунт', en: 'Create an account', kk: 'Аккаунт жасау' },
  name: { ru: 'Имя', en: 'Name', kk: 'Аты' },
  email: { ru: 'Электронная почта', en: 'Email', kk: 'Электрондық пошта' },
  password: { ru: 'Пароль', en: 'Password', kk: 'Құпиясөз' },
  role: { ru: 'Роль', en: 'Role', kk: 'Рөл' },
  student: { ru: 'Ученик', en: 'Student', kk: 'Оқушы' },
  teacher: { ru: 'Учитель', en: 'Teacher', kk: 'Мұғалім' },
  haveAccount: { ru: 'Уже есть аккаунт? Войти', en: 'Already have an account? Sign in', kk: 'Аккаунтыңыз бар ма? Кіріңіз' },
  noAccount: { ru: 'Нет аккаунта? Зарегистрироваться', en: 'No account? Register', kk: 'Аккаунт жоқ па? Тіркеліңіз' },
  signInAction: { ru: 'Войти в аккаунт', en: 'Sign in', kk: 'Аккаунтқа кіру' },
  registerAction: { ru: 'Зарегистрироваться', en: 'Register', kk: 'Тіркелу' },
  invalidLogin: { ru: 'Проверьте почту и пароль.', en: 'Check your email and password.', kk: 'Пошта мен құпиясөзді тексеріңіз.' },
  alreadyExists: { ru: 'Пользователь с такой почтой уже есть.', en: 'An account with this email already exists.', kk: 'Бұл поштаға тіркелген аккаунт бар.' },
  teacherOnly: { ru: 'Эта страница доступна только учителю.', en: 'This page is for teachers only.', kk: 'Бұл бет мұғалімдерге ғана арналған.' },
  teacherPanel: { ru: 'Панель учителя', en: 'Teacher panel', kk: 'Мұғалім панелі' },
  teacherPanelHint: { ru: 'Здесь отображаются результаты учеников.', en: 'Student results appear here.', kk: 'Оқушылардың нәтижелері осында көрсетіледі.' },
  noResults: { ru: 'Пока нет результатов учеников.', en: 'There are no student results yet.', kk: 'Әзірге оқушы нәтижелері жоқ.' },
  studentColumn: { ru: 'Ученик', en: 'Student', kk: 'Оқушы' },
  quizColumn: { ru: 'Викторина', en: 'Quiz', kk: 'Викторина' },
  scoreColumn: { ru: 'Результат', en: 'Score', kk: 'Нәтиже' },
  dateColumn: { ru: 'Дата', en: 'Date', kk: 'Күні' },
  signInToPlay: { ru: 'Чтобы сохранять результаты, сначала войдите или зарегистрируйтесь.', en: 'Sign in or register to save your results.', kk: 'Нәтижені сақтау үшін кіріңіз немесе тіркеліңіз.' },
  studentOnlyOwn: { ru: 'Вы видите свой результат. Все результаты учеников доступны только учителю.', en: 'You can see your result. All student results are available to teachers only.', kk: 'Сіз өз нәтижеңізді көре аласыз. Барлық оқушы нәтижелері тек мұғалімге қолжетімді.' },
  createTest: { ru: 'Создать тест', en: 'Create a test', kk: 'Тест жасау' },
  createTestTitle: { ru: 'Создайте свой тест', en: 'Create your own test', kk: 'Өз тестіңізді жасаңыз' },
  createTestHint: { ru: 'Добавьте вопросы и правильные ответы — ученики увидят тест в общем списке.', en: 'Add questions and correct answers — students will see the test in the quiz list.', kk: 'Сұрақтар мен дұрыс жауаптарды қосыңыз — оқушылар тесті жалпы тізімнен көреді.' },
  testTitle: { ru: 'Название теста', en: 'Test title', kk: 'Тест атауы' },
  testDescription: { ru: 'Описание теста', en: 'Test description', kk: 'Тест сипаттамасы' },
  testCategory: { ru: 'Категория', en: 'Category', kk: 'Санат' },
  questionPrompt: { ru: 'Вопрос', en: 'Question', kk: 'Сұрақ' },
  answerOption: { ru: 'Вариант', en: 'Option', kk: 'Нұсқа' },
  correctOption: { ru: 'Правильный вариант', en: 'Correct option', kk: 'Дұрыс нұсқа' },
  addQuestion: { ru: 'Добавить вопрос', en: 'Add question', kk: 'Сұрақ қосу' },
  removeQuestion: { ru: 'Удалить вопрос', en: 'Remove question', kk: 'Сұрақты өшіру' },
  saveTest: { ru: 'Сохранить тест', en: 'Save test', kk: 'Тестті сақтау' },
  testSaved: { ru: 'Тест сохранён. Ученики уже могут его проходить.', en: 'The test is saved. Students can take it now.', kk: 'Тест сақталды. Оқушылар оны қазір тапсыра алады.' },
  testRequired: { ru: 'Заполните название, описание, вопросы и все варианты ответов.', en: 'Fill in the title, description, questions, and all answer options.', kk: 'Атауды, сипаттаманы, сұрақтарды және барлық жауап нұсқаларын толтырыңыз.' },
  customDifficulty: { ru: 'Тест учителя', en: 'Teacher test', kk: 'Мұғалім тесті' },
};

const text = (value: LocalizedText, language: Language) => value[language];
const t = (key: string, language: Language) => copy[key][language];

const quizzes: Quiz[] = [
  {
    id: 'curious-mix',
    title: { ru: 'Любопытная смесь', en: 'Curious mix', kk: 'Қызықты қоспа' },
    description: { ru: 'Наука, история, культура и приятные неожиданности.', en: 'Science, history, culture, and pleasant surprises.', kk: 'Ғылым, тарих, мәдениет және қызықты тосынсыйлар.' },
    category: 'personal',
    questions: 3,
    minutes: 2,
    color: '#3155d8',
    softColor: '#e4e9ff',
    icon: Sparkles,
    difficulty: { ru: 'Разминка', en: 'Warm-up', kk: 'Жаттығу' },
    questionsData: [
      { prompt: { ru: 'У какого животного отпечатки пальцев похожи на человеческие?', en: 'Which animal has fingerprints similar to humans?', kk: 'Қай жануардың саусақ іздері адамдікіне ұқсайды?' }, options: [{ ru: 'Коала', en: 'Koala', kk: 'Коала' }, { ru: 'Выдра', en: 'Otter', kk: 'Кәмшат' }, { ru: 'Лемур', en: 'Lemur', kk: 'Лемур' }, { ru: 'Тигр', en: 'Tiger', kk: 'Жолбарыс' }], answer: 0, fact: { ru: 'Отпечатки коалы имеют петли и завитки, как у человека.', en: 'Koala fingerprints have loops and whorls like human fingerprints.', kk: 'Коаланың саусақ іздерінде адамдікіндей ілмектер мен бұрылыстар бар.' } },
      { prompt: { ru: 'Какая буква не встречается в таблице химических элементов?', en: 'Which letter does not appear in the periodic table?', kk: 'Химиялық элементтер кестесінде қай әріп кездеспейді?' }, options: [{ ru: 'J', en: 'J', kk: 'J' }, { ru: 'Q', en: 'Q', kk: 'Q' }, { ru: 'X', en: 'X', kk: 'X' }, { ru: 'Z', en: 'Z', kk: 'Z' }], answer: 0, fact: { ru: 'Буква J — единственная, которой нет в обозначениях элементов.', en: 'J is the only letter absent from element symbols.', kk: 'J әрпі элемент таңбаларында кездеспейтін жалғыз әріп.' } },
      { prompt: { ru: 'Какой океан самый маленький?', en: 'Which ocean is the smallest?', kk: 'Ең кішкентай мұхит қайсы?' }, options: [{ ru: 'Индийский', en: 'Indian', kk: 'Үнді' }, { ru: 'Атлантический', en: 'Atlantic', kk: 'Атлант' }, { ru: 'Северный Ледовитый', en: 'Arctic', kk: 'Солтүстік Мұзды' }, { ru: 'Южный', en: 'Southern', kk: 'Оңтүстік' }], answer: 2, fact: { ru: 'Площадь Северного Ледовитого океана — около 14 миллионов квадратных километров.', en: 'The Arctic Ocean covers about 14 million square kilometers.', kk: 'Солтүстік Мұзды мұхиттың ауданы шамамен 14 миллион шаршы километр.' } },
    ],
  },
  {
    id: 'world-in-miniature',
    title: { ru: 'Мир в миниатюре', en: 'World in miniature', kk: 'Шағын әлем' },
    description: { ru: 'Большие места и маленькие детали. Путешествие по планете.', en: 'Big places and small details. A trip around our planet.', kk: 'Үлкен жерлер мен шағын деректер. Планетаға саяхат.' },
    category: 'geography',
    questions: 3,
    minutes: 2,
    color: '#e96b4d',
    softColor: '#ffebe2',
    icon: Compass,
    difficulty: { ru: 'Легко', en: 'Easy', kk: 'Оңай' },
    questionsData: [
      { prompt: { ru: 'В какой стране находится старейший парламент мира?', en: 'Which country has the world’s oldest parliament?', kk: 'Әлемдегі ең көне парламент қай елде орналасқан?' }, options: [{ ru: 'Исландия', en: 'Iceland', kk: 'Исландия' }, { ru: 'Швеция', en: 'Sweden', kk: 'Швеция' }, { ru: 'Канада', en: 'Canada', kk: 'Канада' }, { ru: 'Греция', en: 'Greece', kk: 'Грекия' }], answer: 0, fact: { ru: 'Исландский альтинг был основан в 930 году.', en: 'The Icelandic Alþingi was founded in 930.', kk: 'Исландияның Альтингі 930 жылы құрылған.' } },
      { prompt: { ru: 'Какой остров самый большой в Средиземном море?', en: 'Which is the largest island in the Mediterranean?', kk: 'Жерорта теңізіндегі ең үлкен арал қайсы?' }, options: [{ ru: 'Крит', en: 'Crete', kk: 'Крит' }, { ru: 'Сицилия', en: 'Sicily', kk: 'Сицилия' }, { ru: 'Кипр', en: 'Cyprus', kk: 'Кипр' }, { ru: 'Сардиния', en: 'Sardinia', kk: 'Сардиния' }], answer: 1, fact: { ru: 'Сицилия — крупнейший регион Италии.', en: 'Sicily is Italy’s largest region.', kk: 'Сицилия — Италияның ең үлкен аймағы.' } },
      { prompt: { ru: 'Над какой страной возвышается гора Килиманджаро?', en: 'Mount Kilimanjaro rises above which country?', kk: 'Килиманджаро тауы қай елде орналасқан?' }, options: [{ ru: 'Кения', en: 'Kenya', kk: 'Кения' }, { ru: 'Эфиопия', en: 'Ethiopia', kk: 'Эфиопия' }, { ru: 'Танзания', en: 'Tanzania', kk: 'Танзания' }, { ru: 'Уганда', en: 'Uganda', kk: 'Уганда' }], answer: 2, fact: { ru: 'Килиманджаро — самая высокая гора Африки.', en: 'Kilimanjaro is the highest mountain in Africa.', kk: 'Килиманджаро — Африкадағы ең биік тау.' } },
    ],
  },
  {
    id: 'studio-brain',
    title: { ru: 'Культурный радар', en: 'Culture radar', kk: 'Мәдениет радары' },
    description: { ru: 'Кино, дизайн, музыка и детали культуры.', en: 'Film, design, music, and cultural details.', kk: 'Кино, дизайн, музыка және мәдениет деректері.' },
    category: 'culture',
    questions: 3,
    minutes: 2,
    color: '#db3d87',
    softColor: '#fde2f0',
    icon: BookOpen,
    difficulty: { ru: 'Игриво', en: 'Playful', kk: 'Ойын сияқты' },
    questionsData: [
      { prompt: { ru: 'Кто расписал потолок Сикстинской капеллы?', en: 'Who painted the ceiling of the Sistine Chapel?', kk: 'Сикстин капелласының төбесін кім салған?' }, options: [{ ru: 'Леонардо да Винчи', en: 'Leonardo da Vinci', kk: 'Леонардо да Винчи' }, { ru: 'Микеланджело', en: 'Michelangelo', kk: 'Микеланджело' }, { ru: 'Рафаэль', en: 'Raphael', kk: 'Рафаэль' }, { ru: 'Караваджо', en: 'Caravaggio', kk: 'Караваджо' }], answer: 1, fact: { ru: 'Микеланджело работал над потолком с 1508 по 1512 год.', en: 'Michelangelo worked on the ceiling from 1508 to 1512.', kk: 'Микеланджело төбеде 1508–1512 жылдары жұмыс істеген.' } },
      { prompt: { ru: 'Как называется песня, исполняемая одним человеком?', en: 'What do we call a song performed by one person?', kk: 'Бір адам орындайтын ән қалай аталады?' }, options: [{ ru: 'Соло', en: 'Solo', kk: 'Соло' }, { ru: 'Дуэт', en: 'Duet', kk: 'Дуэт' }, { ru: 'Хор', en: 'Choir', kk: 'Хор' }, { ru: 'Увертюра', en: 'Overture', kk: 'Увертюра' }], answer: 0, fact: { ru: 'Слово «соло» происходит от итальянского «один».', en: 'The word “solo” comes from the Italian word for “alone”.', kk: '«Соло» сөзі итальян тіліндегі «бір» сөзінен шыққан.' } },
      { prompt: { ru: 'Из скольких строк традиционно состоит хайку?', en: 'How many lines does a traditional haiku have?', kk: 'Дәстүрлі хайку неше жолдан тұрады?' }, options: [{ ru: 'Трёх', en: 'Three', kk: 'Үш' }, { ru: 'Четырёх', en: 'Four', kk: 'Төрт' }, { ru: 'Шести', en: 'Six', kk: 'Алты' }, { ru: 'Двух', en: 'Two', kk: 'Екі' }], answer: 0, fact: { ru: 'Классическая схема хайку — 5, 7, 5 слогов в трёх строках.', en: 'The classic haiku pattern is 5, 7, 5 syllables across three lines.', kk: 'Классикалық хайку үш жолда 5, 7, 5 буыннан тұрады.' } },
    ],
  },
  {
    id: 'why-things-work',
    title: { ru: 'Почему всё работает', en: 'Why things work', kk: 'Заттар неге жұмыс істейді?' },
    description: { ru: 'Повседневная наука для внимательных.', en: 'Everyday science for curious minds.', kk: 'Ізденімпаздарға арналған күнделікті ғылым.' },
    category: 'science',
    questions: 3,
    minutes: 2,
    color: '#158a78',
    softColor: '#d9f2ec',
    icon: Lightbulb,
    difficulty: { ru: 'Заставит подумать', en: 'Think a little', kk: 'Ойлануға' },
    questionsData: [
      { prompt: { ru: 'Почему лёд плавает на поверхности воды?', en: 'Why does ice float on water?', kk: 'Мұз неге суда қалқып жүреді?' }, options: [{ ru: 'Он холоднее', en: 'It is colder', kk: 'Ол суығырақ' }, { ru: 'Он менее плотный', en: 'It is less dense', kk: 'Оның тығыздығы төмен' }, { ru: 'В нём больше кислорода', en: 'It has more oxygen', kk: 'Онда оттегі көп' }, { ru: 'Он тяжелее', en: 'It is heavier', kk: 'Ол ауырлау' }], answer: 1, fact: { ru: 'При замерзании вода расширяется, поэтому лёд менее плотный.', en: 'Water expands when it freezes, making ice less dense.', kk: 'Су қатқанда кеңейеді, сондықтан мұздың тығыздығы төмен.' } },
      { prompt: { ru: 'Какая сила удерживает планеты на орбитах?', en: 'What force keeps planets in orbit?', kk: 'Планеталарды орбитада қандай күш ұстап тұрады?' }, options: [{ ru: 'Трение', en: 'Friction', kk: 'Үйкеліс' }, { ru: 'Магнетизм', en: 'Magnetism', kk: 'Магнетизм' }, { ru: 'Гравитация', en: 'Gravity', kk: 'Гравитация' }, { ru: 'Давление', en: 'Pressure', kk: 'Қысым' }], answer: 2, fact: { ru: 'Гравитация удерживает планеты рядом с Солнцем.', en: 'Gravity keeps planets moving around the Sun.', kk: 'Гравитация планеталарды Күнді айналып қозғалуға ұстайды.' } },
      { prompt: { ru: 'Какой газ растения поглощают во время фотосинтеза?', en: 'Which gas do plants absorb during photosynthesis?', kk: 'Өсімдіктер фотосинтез кезінде қандай газды сіңіреді?' }, options: [{ ru: 'Кислород', en: 'Oxygen', kk: 'Оттегі' }, { ru: 'Азот', en: 'Nitrogen', kk: 'Азот' }, { ru: 'Углекислый газ', en: 'Carbon dioxide', kk: 'Көмірқышқыл газы' }, { ru: 'Водород', en: 'Hydrogen', kk: 'Сутек' }], answer: 2, fact: { ru: 'Растения превращают углекислый газ и воду в сахар с помощью света.', en: 'Plants use light to turn carbon dioxide and water into sugar.', kk: 'Өсімдіктер жарық көмегімен көмірқышқыл газы мен суды қантқа айналдырады.' } },
    ],
  },
];

const categoryIcons: Record<Exclude<Category, 'all'>, LucideIcon> = {
  personal: Sparkles,
  geography: Compass,
  culture: BookOpen,
  science: Lightbulb,
};

function getAllQuizzes(): Quiz[] {
  const stored = readStorage<StoredQuiz[]>('quizly_custom_quizzes', []);
  return [...quizzes, ...stored.map((quiz) => ({ ...quiz, icon: categoryIcons[quiz.category] }))];
}

function localized(value: string): LocalizedText {
  return { ru: value, en: value, kk: value };
}

function readStorage<T>(key: string, fallback: T): T {
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeStorage(key: string, value: unknown) {
  window.localStorage.setItem(key, JSON.stringify(value));
}

function Brand() {
  return (
    <Link href="/" className="brand-mark flex items-center gap-2 text-xl font-extrabold text-[#172026]" data-testid="link-brand">
      <span className="grid size-8 place-items-center rounded-[10px] bg-[#3155d8] text-[#f9f4e9] shadow-[3px_3px_0_#172026]">
        <Zap size={17} strokeWidth={3} />
      </span>
      <span>quizly</span>
    </Link>
  );
}

function Shell({ children, language, setLanguage, user, onLogout }: { children: ReactNode; language: Language; setLanguage: (language: Language) => void; user?: User; onLogout: () => void }) {
  const [location] = useLocation();
  return (
    <div className="quiz-app relative min-h-[100dvh]">
      <header className="relative z-10 mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-5 md:px-10 md:py-7">
        <Brand />
        <div className="flex flex-wrap items-center justify-end gap-2 text-sm font-semibold text-[#52606b]">
          <div className="flex overflow-hidden rounded-full border border-[#ded6c9] bg-[#fbf8f0]/70">
            {languages.map((item) => (
              <button key={item.id} onClick={() => setLanguage(item.id)} className={`px-3 py-2 text-xs transition-colors ${language === item.id ? 'bg-[#3155d8] text-white' : 'hover:bg-[#e7e1d4]'}`} data-testid={`button-language-${item.id}`}>{item.label}</button>
            ))}
          </div>
          <span className="hidden items-center gap-2 rounded-full border border-[#ded6c9] bg-[#fbf8f0]/70 px-3 py-2 lg:flex"><Flame size={15} className="text-[#e96b4d]" />{t('headerNote', language)}</span>
          {user ? (
            <>
              <span className="hidden items-center gap-1 rounded-full bg-[#d6ef4a] px-3 py-2 text-[#172026] sm:flex"><UserRound size={14} />{user.name}</span>
              {user.role === 'teacher' && <Link href="/create-test" className="rounded-full px-3 py-2 hover:bg-[#e7e1d4]" data-testid="link-create-test"><BookOpen size={15} className="mr-1 inline" />{t('createTest', language)}</Link>}
              {user.role === 'teacher' && <Link href="/teacher-results" className="rounded-full px-3 py-2 hover:bg-[#e7e1d4]" data-testid="link-teacher-results"><UsersRound size={15} className="mr-1 inline" />{t('teacherResults', language)}</Link>}
              <button onClick={onLogout} className="rounded-full px-3 py-2 hover:bg-[#e7e1d4]" data-testid="button-logout">{t('logout', language)}</button>
            </>
          ) : (
            <>
              <Link href="/auth?mode=login" className="rounded-full px-3 py-2 hover:bg-[#e7e1d4]" data-testid="link-sign-in">{t('signIn', language)}</Link>
              <Link href="/auth?mode=register" className="rounded-full bg-[#e96b4d] px-4 py-2 text-[#172026] shadow-[3px_3px_0_#172026]" data-testid="link-register">{t('register', language)}</Link>
            </>
          )}
          {location !== '/' && <Link href="/" className="hidden rounded-full px-3 py-2 hover:bg-[#e7e1d4] md:block" data-testid="link-home-header"><House size={15} className="mr-1 inline" />{t('home', language)}</Link>}
        </div>
      </header>
      <main className="relative z-[1]">{children}</main>
      <footer className="relative z-[1] mx-auto mt-14 flex max-w-7xl items-center justify-between border-t border-[#ded6c9] px-5 py-7 text-xs font-semibold tracking-wide text-[#7b817e] md:px-10">
        <span className="brand-mark text-sm text-[#3155d8]">quizly</span>
        <span>{language === 'ru' ? 'Для любопытных минут.' : language === 'en' ? 'For curious minutes.' : 'Қызықты минуттар үшін.'}</span>
      </footer>
    </div>
  );
}

function Home({ language, user, onStart, onSetLanguage, onLogout }: { language: Language; user?: User; onStart: (quiz: Quiz) => void; onSetLanguage: (language: Language) => void; onLogout: () => void }) {
  const [activeCategory, setActiveCategory] = useState<Category>('all');
  const categories: Array<{ id: Category; label: string }> = [
    { id: 'all', label: t('allQuizzes', language) },
    { id: 'personal', label: t('forYou', language) },
    { id: 'geography', label: t('geography', language) },
    { id: 'culture', label: t('culture', language) },
    { id: 'science', label: t('science', language) },
  ];
  const visibleQuizzes = activeCategory === 'all' ? getAllQuizzes() : getAllQuizzes().filter((quiz) => quiz.category === activeCategory);
  return (
    <Shell language={language} setLanguage={onSetLanguage} user={user} onLogout={onLogout}>
      <section className="mx-auto grid max-w-7xl gap-10 px-5 pb-10 pt-5 md:grid-cols-[1.08fr_.92fr] md:items-center md:px-10 md:pb-20 md:pt-14">
        <div className="animate-rise">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#d7cfbf] bg-[#f7f0e2] px-3 py-2 text-xs font-bold text-[#3155d8]"><Sparkles size={14} /> {t('heroEyebrow', language)}</div>
          <h1 className="display max-w-[650px] text-[clamp(3.2rem,7vw,6.8rem)] font-bold leading-[.88] text-[#172026]">
            {t('heroOne', language)}<br />{t('heroTwo', language)}<br /><span className="text-[#e96b4d]">{t('heroThree', language)}</span>
          </h1>
          <p className="mt-7 max-w-[520px] text-base leading-7 text-[#52606b] md:text-lg">{t('heroDescription', language)}</p>
          <div className="mt-8 flex flex-wrap items-center gap-4 text-sm font-semibold text-[#52606b]">
            <span className="flex items-center gap-2"><Clock3 size={17} className="text-[#3155d8]" /> {t('roundTime', language)}</span>
            <span className="flex items-center gap-2"><CircleHelp size={17} className="text-[#e96b4d]" /> {t('noRegistration', language)}</span>
          </div>
        </div>
        <div className="relative mx-auto h-[300px] w-full max-w-[450px] md:h-[390px]">
          <div className="absolute right-[4%] top-[8%] h-[230px] w-[190px] rotate-[10deg] rounded-[28px] border-2 border-[#172026] bg-[#d6ef4a] p-6 shadow-[8px_9px_0_#172026] md:h-[285px] md:w-[230px]">
            <div className="flex items-start justify-between"><span className="rounded-full border border-[#172026] px-2 py-1 text-[10px] font-bold uppercase tracking-wider">02 / 08</span><Trophy size={20} /></div>
            <p className="display mt-16 max-w-[155px] text-2xl font-bold leading-[.95] text-[#172026] md:mt-20 md:max-w-[185px] md:text-4xl">{language === 'en' ? <>Are you<br />curious?</> : language === 'kk' ? <>Қызық<br />па?</> : <>Любопытны<br />ли вы?</>}</p>
            <div className="absolute bottom-5 right-5 flex size-9 items-center justify-center rounded-full bg-[#e96b4d]"><ArrowRight size={18} /></div>
          </div>
          <div className="floating-card absolute bottom-[7%] left-[5%] z-[1] h-[220px] w-[188px] rounded-[28px] border-2 border-[#172026] bg-[#3155d8] p-6 text-[#f9f4e9] shadow-[8px_9px_0_#172026] md:h-[270px] md:w-[220px]">
            <div className="flex items-start justify-between"><Sparkles size={20} /><span className="text-xs font-bold">quizly</span></div>
            <p className="display mt-14 text-3xl font-bold leading-[.95] md:mt-16 md:text-4xl">{language === 'en' ? <>Small<br />questions.<br /><span className="text-[#d6ef4a]">Big spark.</span></> : language === 'kk' ? <>Шағын<br />сұрақтар.<br /><span className="text-[#d6ef4a]">Үлкен ұшқын.</span></> : <>Маленькие<br />вопросы.<br /><span className="text-[#d6ef4a]">Большая<br />искра.</span></>}</p>
            <div className="absolute bottom-6 left-6 right-6 h-1 rounded-full bg-[#f9f4e9]/35"><div className="h-full w-2/5 rounded-full bg-[#d6ef4a]" /></div>
          </div>
          <div className="absolute bottom-2 right-[3%] size-16 rotate-12 rounded-[18px] border-2 border-[#172026] bg-[#e96b4d] shadow-[4px_5px_0_#172026] md:size-20" />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 md:px-10 md:pb-24">
        <div className="mb-7 flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div><p className="eyebrow text-[#e96b4d]">{t('chooseMood', language)}</p><h2 className="display mt-2 text-4xl font-bold text-[#172026] md:text-5xl">{t('thinkAbout', language)}</h2></div>
          <div className="flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label={t('chooseQuiz', language)}>
            {categories.map((category) => <button key={category.id} onClick={() => setActiveCategory(category.id)} className={`whitespace-nowrap rounded-full border px-4 py-2.5 text-sm font-bold transition-all ${activeCategory === category.id ? 'border-[#3155d8] bg-[#3155d8] text-[#f9f4e9]' : 'border-[#d7cfbf] bg-[#f8f2e7] text-[#52606b] hover:border-[#3155d8] hover:text-[#3155d8]'}`} data-testid={`button-category-${category.id}`}>{category.label}</button>)}
          </div>
        </div>
        {visibleQuizzes.length ? <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">{visibleQuizzes.map((quiz, index) => <QuizCard key={quiz.id} quiz={quiz} index={index} language={language} onStart={onStart} />)}</div> : <div className="animate-pop rounded-[28px] border-2 border-dashed border-[#d7cfbf] bg-[#f8f2e7] px-6 py-16 text-center"><Compass className="mx-auto text-[#3155d8]" size={32} /><h3 className="display mt-4 text-3xl font-bold">{t('noQuizzes', language)}</h3><p className="mt-2 text-[#52606b]">{t('noQuizzesHint', language)}</p></div>}
      </section>
      <section className="mx-auto grid max-w-7xl gap-6 px-5 pb-8 md:grid-cols-[.75fr_1.25fr] md:px-10">
        <div className="rounded-[28px] bg-[#172026] p-7 text-[#f9f4e9] md:p-9"><Medal className="mb-8 text-[#d6ef4a]" size={28} /><p className="eyebrow text-[#d6ef4a]">{language === 'ru' ? 'Самое интересное' : language === 'en' ? 'The best part' : 'Ең қызықтысы'}</p><p className="display mt-3 text-3xl font-bold leading-tight">{language === 'ru' ? 'Унесите с собой факт, которым захочется поделиться.' : language === 'en' ? 'Take away a fact you will want to share.' : 'Бөліскіңіз келетін жаңа дерек алыңыз.'}</p></div>
        <div className="flex flex-col justify-between rounded-[28px] border border-[#d7cfbf] bg-[#f7f0e2] p-7 md:flex-row md:items-end md:p-9"><div><p className="eyebrow text-[#e96b4d]">{language === 'ru' ? 'Как это работает' : language === 'en' ? 'How it works' : 'Бұл қалай жұмыс істейді'}</p><h3 className="display mt-3 max-w-lg text-3xl font-bold leading-tight text-[#172026]">{language === 'ru' ? 'Выберите тему, отвечайте и узнайте что-нибудь новое.' : language === 'en' ? 'Choose a topic, answer, and learn something new.' : 'Тақырып таңдаңыз, жауап беріңіз және жаңа нәрсе үйреніңіз.'}</h3></div><div className="mt-6 flex gap-7 text-sm text-[#52606b] md:mt-0"><span><strong className="block text-2xl text-[#3155d8]">01</strong>{language === 'ru' ? 'Выберите' : language === 'en' ? 'Choose' : 'Таңдаңыз'}</span><span><strong className="block text-2xl text-[#3155d8]">02</strong>{language === 'ru' ? 'Играйте' : language === 'en' ? 'Play' : 'Ойнаңыз'}</span><span><strong className="block text-2xl text-[#3155d8]">03</strong>{language === 'ru' ? 'Узнайте' : language === 'en' ? 'Learn' : 'Біліңіз'}</span></div></div>
      </section>
    </Shell>
  );
}

function QuizCard({ quiz, index, language, onStart }: { quiz: Quiz; index: number; language: Language; onStart: (quiz: Quiz) => void }) {
  const Icon = quiz.icon;
  const categoryKey = quiz.category === 'personal' ? 'forYou' : quiz.category;
  return <article className="animate-rise group relative flex min-h-[295px] flex-col overflow-hidden rounded-[27px] border-2 border-[#172026] bg-[#f9f4e9] p-6 shadow-[5px_6px_0_#172026] transition-transform duration-300 hover:-translate-y-2" style={{ animationDelay: `${index * 70}ms` }} data-testid={`card-quiz-${quiz.id}`}>
    <div className="absolute -right-8 -top-8 size-28 rounded-full opacity-80 transition-transform duration-500 group-hover:scale-125" style={{ backgroundColor: quiz.softColor }} />
    <div className="relative flex items-center justify-between"><span className="grid size-11 place-items-center rounded-2xl text-[#f9f4e9]" style={{ backgroundColor: quiz.color }}><Icon size={21} /></span><span className="eyebrow text-[#7b817e]">{t(categoryKey, language)}</span></div>
    <div className="relative mt-7"><h3 className="display text-3xl font-bold leading-[.95] text-[#172026]">{text(quiz.title, language)}</h3><p className="mt-3 text-sm leading-5 text-[#657078]">{text(quiz.description, language)}</p></div>
    <div className="mt-auto flex items-end justify-between pt-6"><div className="text-xs font-bold text-[#7b817e]"><span className="mr-3">{quiz.questions} {t('questions', language)}</span><span>{text(quiz.difficulty, language)}</span></div><button onClick={() => onStart(quiz)} className="primary-button grid size-11 place-items-center rounded-full bg-[#e96b4d] text-[#172026]" aria-label={`${t('start', language)}: ${text(quiz.title, language)}`} data-testid={`button-start-${quiz.id}`}><ArrowRight size={20} /></button></div>
  </article>;
}

function AuthView({ language, setLanguage, onAuth, onLogout, user }: { language: Language; setLanguage: (language: Language) => void; onAuth: (user: User) => void; onLogout: () => void; user?: User }) {
  const [location, setLocation] = useLocation();
  const initialMode = new URLSearchParams(window.location.search).get('mode') === 'register' ? 'register' : 'login';
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<Role>('student');
  const [error, setError] = useState('');

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    const users = readStorage<User[]>('quizly_users', []);
    const normalizedEmail = email.trim().toLowerCase();
    if (mode === 'register') {
      if (users.some((item) => item.email === normalizedEmail)) {
        setError(t('alreadyExists', language));
        return;
      }
      const newUser = { id: crypto.randomUUID(), name: name.trim() || normalizedEmail.split('@')[0], email: normalizedEmail, password, role };
      writeStorage('quizly_users', [...users, newUser]);
      writeStorage('quizly_current_user', newUser);
      onAuth(newUser);
      setLocation('/');
      return;
    }
    const found = users.find((item) => item.email === normalizedEmail && item.password === password);
    if (!found) {
      setError(t('invalidLogin', language));
      return;
    }
    writeStorage('quizly_current_user', found);
    onAuth(found);
    setLocation('/');
  }

  return <Shell language={language} setLanguage={setLanguage} user={user} onLogout={onLogout}>
    <div className="mx-auto max-w-xl px-5 pb-24 pt-10 md:pt-20">
      <div className="rounded-[30px] border-2 border-[#172026] bg-[#f9f4e9] p-7 shadow-[6px_7px_0_#172026] md:p-10">
        <p className="eyebrow text-[#e96b4d]">{mode === 'register' ? t('register', language) : t('signIn', language)}</p>
        <h1 className="display mt-3 text-5xl font-bold leading-[.95] text-[#172026]">{mode === 'register' ? t('createAccount', language) : t('authTitle', language)}</h1>
        <p className="mt-4 leading-6 text-[#657078]">{t('authSubtitle', language)}</p>
        <form onSubmit={submit} className="mt-8 grid gap-4">
          {mode === 'register' && <label className="grid gap-2 text-sm font-bold text-[#52606b]">{t('name', language)}<input value={name} onChange={(event) => setName(event.target.value)} required className="rounded-xl border border-[#d7cfbf] bg-[#fffaf2] px-4 py-3 outline-none focus:border-[#3155d8]" /></label>}
          <label className="grid gap-2 text-sm font-bold text-[#52606b]">{t('email', language)}<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required className="rounded-xl border border-[#d7cfbf] bg-[#fffaf2] px-4 py-3 outline-none focus:border-[#3155d8]" /></label>
          <label className="grid gap-2 text-sm font-bold text-[#52606b]">{t('password', language)}<input type="password" minLength={4} value={password} onChange={(event) => setPassword(event.target.value)} required className="rounded-xl border border-[#d7cfbf] bg-[#fffaf2] px-4 py-3 outline-none focus:border-[#3155d8]" /></label>
          {mode === 'register' && <label className="grid gap-2 text-sm font-bold text-[#52606b]">{t('role', language)}<select value={role} onChange={(event) => setRole(event.target.value as Role)} className="rounded-xl border border-[#d7cfbf] bg-[#fffaf2] px-4 py-3 outline-none focus:border-[#3155d8]"><option value="student">{t('student', language)}</option><option value="teacher">{t('teacher', language)}</option></select></label>}
          {error && <p className="rounded-xl bg-[#ffebe2] px-4 py-3 text-sm font-semibold text-[#b74431]">{error}</p>}
          <button type="submit" className="primary-button mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-[#3155d8] px-5 py-3.5 font-bold text-white">{mode === 'register' ? t('registerAction', language) : t('signInAction', language)} <ArrowRight size={17} /></button>
        </form>
        <button onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }} className="mt-6 w-full text-sm font-bold text-[#3155d8] hover:underline">{mode === 'login' ? t('noAccount', language) : t('haveAccount', language)}</button>
      </div>
    </div>
  </Shell>;
}

function Play({ quiz, answers, setAnswers, language, onFinish, onHome, user, onLogout, setLanguage }: { quiz?: Quiz; answers: Array<number | null>; setAnswers: (answers: Array<number | null>) => void; language: Language; onFinish: () => void; onHome: () => void; user?: User; onLogout: () => void; setLanguage: (language: Language) => void }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [seconds, setSeconds] = useState(30);
  const [timedOut, setTimedOut] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const question = quiz?.questionsData[currentIndex];
  const selected = answers[currentIndex] ?? null;
  const isAnswered = selected !== null || timedOut;

  useEffect(() => { setSeconds(30); setTimedOut(false); setIsTransitioning(false); }, [currentIndex]);
  useEffect(() => { if (!quiz || isAnswered) return; const timer = window.setInterval(() => setSeconds((value) => value <= 1 ? 0 : value - 1), 1000); return () => window.clearInterval(timer); }, [quiz, currentIndex, isAnswered]);
  useEffect(() => { if (!quiz || seconds !== 0 || isAnswered) return; setTimedOut(true); const timeout = window.setTimeout(() => advance(), 900); return () => window.clearTimeout(timeout); }, [seconds, isAnswered, quiz]);

  if (!quiz || !question) return <Shell language={language} setLanguage={setLanguage} user={user} onLogout={onLogout}><EmptyPlay language={language} onHome={onHome} /></Shell>;
  function chooseAnswer(option: number) { if (isAnswered) return; const nextAnswers = [...answers]; nextAnswers[currentIndex] = option; setAnswers(nextAnswers); }
  function advance() { if (isTransitioning || !quiz) return; if (currentIndex === quiz.questionsData.length - 1) { onFinish(); return; } setIsTransitioning(true); window.setTimeout(() => setCurrentIndex((value) => value + 1), 220); }
  return <Shell language={language} setLanguage={setLanguage} user={user} onLogout={onLogout}>
    <div className="mx-auto max-w-4xl px-5 pb-16 pt-6 md:px-10 md:pt-14">
      <div className="mb-8 flex items-center justify-between gap-4"><Link href="/" className="flex items-center gap-2 text-sm font-bold text-[#657078] hover:text-[#3155d8]" data-testid="link-back-home"><ArrowLeft size={17} /> {t('backToQuizzes', language)}</Link><div className="flex items-center gap-3 text-sm font-bold text-[#657078]"><span>{currentIndex + 1} <span className="text-[#abb0ac]">/ {quiz.questionsData.length}</span></span><div className="h-2 w-24 overflow-hidden rounded-full bg-[#ded6c9] md:w-40"><div className="progress-fill h-full rounded-full bg-[#3155d8]" style={{ width: `${((currentIndex + 1) / quiz.questionsData.length) * 100}%` }} /></div></div></div>
      <div className="mb-10 h-1.5 overflow-hidden rounded-full bg-[#ded6c9]"><div className="progress-fill h-full rounded-full bg-[#e96b4d]" style={{ width: `${((currentIndex + 1) / quiz.questionsData.length) * 100}%` }} /></div>
      <div className={`transition-all duration-200 ${isTransitioning ? 'translate-x-3 opacity-0' : 'translate-x-0 opacity-100'}`}>
        <div className="mb-9 flex items-start justify-between gap-6"><div><p className="eyebrow text-[#e96b4d]">{text(quiz.title, language)}</p><h1 className="display mt-4 max-w-3xl text-4xl font-bold leading-[.98] text-[#172026] md:text-6xl" data-testid={`text-question-${currentIndex}`}>{text(question.prompt, language)}</h1></div><div className={`relative hidden size-16 shrink-0 md:block ${seconds < 8 && !isAnswered ? 'text-[#e96b4d]' : 'text-[#3155d8]'}`}><svg viewBox="0 0 52 52" className="size-full"><circle cx="26" cy="26" r="22" fill="none" stroke="currentColor" strokeOpacity=".15" strokeWidth="4" /><circle className="timer-ring" cx="26" cy="26" r="22" fill="none" stroke="currentColor" strokeWidth="4" strokeDasharray={2 * Math.PI * 22} strokeDashoffset={(2 * Math.PI * 22) * (1 - seconds / 30)} strokeLinecap="round" /></svg><span className="absolute inset-0 grid place-items-center text-sm font-bold">{seconds}</span></div></div>
        <div className="grid gap-3" role="radiogroup" aria-label={t('question', language)}>{question.options.map((option, optionIndex) => { const chosen = selected === optionIndex; const correct = isAnswered && optionIndex === question.answer; const incorrect = chosen && !correct; return <button key={option.en} onClick={() => chooseAnswer(optionIndex)} disabled={isAnswered} className={`choice-button flex min-h-[68px] items-center gap-4 rounded-2xl border-2 bg-[#f9f4e9] px-5 text-left text-base font-semibold text-[#172026] ${correct ? 'border-[#158a78] bg-[#d9f2ec]' : ''} ${incorrect ? 'border-[#e96b4d] bg-[#ffebe2]' : ''} ${!isAnswered ? 'border-[#ded6c9] hover:border-[#3155d8]' : ''}`} role="radio" aria-checked={chosen}><span className={`grid size-9 shrink-0 place-items-center rounded-xl border text-sm font-bold ${correct ? 'border-[#158a78] bg-[#158a78] text-[#f9f4e9]' : incorrect ? 'border-[#e96b4d] bg-[#e96b4d] text-[#172026]' : chosen ? 'border-[#3155d8] bg-[#3155d8] text-[#f9f4e9]' : 'border-[#d7cfbf] bg-[#f7f0e2] text-[#657078]'}`}>{correct ? <Check size={17} strokeWidth={3} /> : incorrect ? <X size={17} strokeWidth={3} /> : String.fromCharCode(65 + optionIndex)}</span><span>{text(option, language)}</span></button>; })}</div>
        <div className={`mt-6 flex flex-col gap-4 rounded-2xl px-5 py-4 transition-all duration-300 sm:flex-row sm:items-center sm:justify-between ${isAnswered ? 'bg-[#172026] text-[#f9f4e9]' : 'pointer-events-none opacity-0'}`}><p className="text-sm leading-5">{timedOut ? <><strong>{t('timeUp', language)}</strong> {text(question.options[question.answer], language)}.</> : selected === question.answer ? <><strong>{t('excellent', language)}</strong> {text(question.fact, language)}</> : <><strong>{t('goodTry', language)}</strong> {text(question.options[question.answer], language)}.</>}</p><button onClick={advance} className="flex shrink-0 items-center justify-center gap-2 rounded-full bg-[#d6ef4a] px-5 py-3 text-sm font-bold text-[#172026] hover:translate-x-1" data-testid="button-next-question">{currentIndex === quiz.questionsData.length - 1 ? t('seeResult', language) : t('next', language)} <ArrowRight size={16} /></button></div>
      </div>
    </div>
  </Shell>;
}

function EmptyPlay({ language, onHome }: { language: Language; onHome: () => void }) {
  return <div className="mx-auto max-w-xl px-5 py-24 text-center md:py-36"><div className="mx-auto grid size-20 place-items-center rounded-[25px] bg-[#d6ef4a] text-[#172026] shadow-[5px_6px_0_#172026]"><CircleHelp size={35} /></div><h1 className="display mt-8 text-5xl font-bold text-[#172026]">{t('chooseQuiz', language)}</h1><button onClick={onHome} className="primary-button mt-8 inline-flex items-center gap-2 rounded-full bg-[#3155d8] px-6 py-3.5 font-bold text-[#f9f4e9]">{t('home', language)} <ArrowRight size={17} /></button></div>;
}

function Results({ quiz, answers, language, user, onRestart, onHome, onLogout, setLanguage }: { quiz?: Quiz; answers: Array<number | null>; language: Language; user?: User; onRestart: () => void; onHome: () => void; onLogout: () => void; setLanguage: (language: Language) => void }) {
  const score = useMemo(() => quiz ? answers.reduce<number>((total, answer, index) => total + (answer === quiz.questionsData[index]?.answer ? 1 : 0), 0) : 0, [quiz, answers]);
  if (!quiz) return <Shell language={language} setLanguage={setLanguage} user={user} onLogout={onLogout}><EmptyResults language={language} onHome={onHome} /></Shell>;
  const percentage = Math.round((score / quiz.questionsData.length) * 100);
  const resultCopy = percentage >= 80 ? t('resultHigh', language) : percentage >= 50 ? t('resultMid', language) : t('resultLow', language);
  return <Shell language={language} setLanguage={setLanguage} user={user} onLogout={onLogout}>
    <div className="mx-auto max-w-5xl px-5 pb-20 pt-8 md:px-10 md:pt-14">
      <div className="grid gap-7 md:grid-cols-[.85fr_1.15fr]">
        <div className="animate-rise rounded-[30px] bg-[#3155d8] p-7 text-[#f9f4e9] shadow-[7px_8px_0_#172026] md:p-10"><div className="flex items-center justify-between"><Trophy className="text-[#d6ef4a]" size={30} /><span className="eyebrow text-[#d6ef4a]">{t('roundFinished', language)}</span></div><p className="eyebrow mt-16 text-[#d6ef4a]">{text(quiz.title, language)}</p><h1 className="display mt-3 text-5xl font-bold leading-[.95] md:text-6xl">{language === 'en' ? <>That was<br />great.</> : language === 'kk' ? <>Бұл<br />керемет.</> : <>Это было<br />здорово.</>}</h1><div className="mt-12 flex items-end gap-3"><span className="display text-8xl font-bold leading-none text-[#d6ef4a]" data-testid="text-score">{score}</span><span className="mb-2 text-lg font-bold text-[#dfe5ff]">/ {quiz.questionsData.length}<br /><span className="text-sm font-medium">{t('correct', language)}</span></span></div></div>
        <div className="animate-rise rounded-[30px] border-2 border-[#172026] bg-[#f9f4e9] p-7 shadow-[5px_6px_0_#172026] md:p-10"><div className="flex items-center justify-between"><div><p className="eyebrow text-[#e96b4d]">{t('yourResult', language)}</p><p className="mt-2 text-sm font-semibold text-[#657078]">{percentage}%</p></div><div className="grid size-16 place-items-center rounded-full bg-[#d6ef4a] text-xl font-bold text-[#172026]">{percentage}%</div></div><h2 className="display mt-12 text-4xl font-bold leading-tight text-[#172026]">{resultCopy}</h2><p className="mt-4 max-w-md leading-6 text-[#657078]">{user?.role === 'student' ? t('studentOnlyOwn', language) : ''}</p><div className="mt-9 flex flex-wrap gap-3"><button onClick={onRestart} className="primary-button inline-flex items-center gap-2 rounded-full bg-[#e96b4d] px-5 py-3.5 text-sm font-bold text-[#172026]"><RotateCcw size={16} /> {t('playAgain', language)}</button><button onClick={onHome} className="inline-flex items-center gap-2 rounded-full border-2 border-[#d7cfbf] px-5 py-3 text-sm font-bold text-[#52606b] hover:border-[#3155d8] hover:text-[#3155d8]"><House size={16} /> {t('home', language)}</button></div></div>
      </div>
      <div className="mt-12"><div className="mb-5 flex items-end justify-between"><div><p className="eyebrow text-[#e96b4d]">{t('shortReview', language)}</p><h2 className="display mt-2 text-3xl font-bold text-[#172026]">{language === 'en' ? 'What did you learn?' : language === 'kk' ? 'Нені есте сақтадыңыз?' : 'Что запомнилось?'}</h2></div><span className="text-sm font-bold text-[#657078]">{score} / {quiz.questionsData.length}</span></div><div className="grid gap-3">{quiz.questionsData.map((question, index) => { const correct = answers[index] === question.answer; return <div key={question.prompt.en} className="flex items-center gap-4 rounded-2xl border border-[#ded6c9] bg-[#f7f0e2] px-4 py-4"><span className={`grid size-9 shrink-0 place-items-center rounded-xl ${correct ? 'bg-[#d9f2ec] text-[#158a78]' : 'bg-[#ffebe2] text-[#e96b4d]'}`}>{correct ? <Check size={17} strokeWidth={3} /> : <X size={17} strokeWidth={3} />}</span><p className="text-sm font-semibold leading-5 text-[#52606b]">{text(question.prompt, language)}</p><span className="ml-auto hidden text-xs font-bold text-[#7b817e] sm:block">{correct ? t('excellent', language) : t('goodTry', language)}</span></div>; })}</div></div>
    </div>
  </Shell>;
}

function EmptyResults({ language, onHome }: { language: Language; onHome: () => void }) {
  return <div className="mx-auto max-w-xl px-5 py-28 text-center"><Crown className="mx-auto text-[#e96b4d]" size={38} /><h1 className="display mt-7 text-5xl font-bold">{t('yourResult', language)}</h1><button onClick={onHome} className="primary-button mt-8 rounded-full bg-[#3155d8] px-6 py-3.5 font-bold text-[#f9f4e9]">{t('chooseQuiz', language)}</button></div>;
}

function CreateTest({ language, setLanguage, user, onLogout }: { language: Language; setLanguage: (language: Language) => void; user?: User; onLogout: () => void }) {
  const [, setLocation] = useLocation();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<Exclude<Category, 'all'>>('personal');
  const [questions, setQuestions] = useState<Array<{ prompt: string; options: string[]; answer: number }>>([{ prompt: '', options: ['', '', '', ''], answer: 0 }]);
  const [error, setError] = useState('');

  if (!user || user.role !== 'teacher') {
    return <Shell language={language} setLanguage={setLanguage} user={user} onLogout={onLogout}><div className="mx-auto max-w-xl px-5 py-32 text-center"><UsersRound className="mx-auto text-[#e96b4d]" size={40} /><h1 className="display mt-7 text-5xl font-bold">{t('teacherOnly', language)}</h1><Link href="/" className="primary-button mt-8 inline-flex rounded-full bg-[#3155d8] px-6 py-3.5 font-bold text-white">{t('home', language)}</Link></div></Shell>;
  }

  function updateQuestion(index: number, update: Partial<{ prompt: string; options: string[]; answer: number }>) {
    setQuestions((current) => current.map((question, questionIndex) => questionIndex === index ? { ...question, ...update } : question));
  }

  function updateOption(questionIndex: number, optionIndex: number, value: string) {
    const nextOptions = [...questions[questionIndex].options];
    nextOptions[optionIndex] = value;
    updateQuestion(questionIndex, { options: nextOptions });
  }

  function saveTest(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    if (!title.trim() || !description.trim() || questions.some((question) => !question.prompt.trim() || question.options.some((option) => !option.trim()))) {
      setError(t('testRequired', language));
      return;
    }
    const newQuiz: StoredQuiz = {
      id: `teacher-${crypto.randomUUID()}`,
      title: localized(title.trim()),
      description: localized(description.trim()),
      category,
      questions: questions.length,
      minutes: Math.max(2, questions.length),
      color: '#3155d8',
      softColor: '#e4e9ff',
      difficulty: localized(t('customDifficulty', language)),
      questionsData: questions.map((question) => ({
        prompt: localized(question.prompt.trim()),
        options: question.options.map((option) => localized(option.trim())),
        answer: question.answer,
        fact: localized(t('customDifficulty', language)),
      })),
    };
    const saved = readStorage<StoredQuiz[]>('quizly_custom_quizzes', []);
    writeStorage('quizly_custom_quizzes', [newQuiz, ...saved]);
    setLocation('/');
  }

  return <Shell language={language} setLanguage={setLanguage} user={user} onLogout={onLogout}>
    <div className="mx-auto max-w-4xl px-5 pb-24 pt-10 md:px-10 md:pt-16">
      <div className="mb-10"><p className="eyebrow text-[#e96b4d]">{t('createTest', language)}</p><h1 className="display mt-3 text-5xl font-bold leading-[.95] text-[#172026]">{t('createTestTitle', language)}</h1><p className="mt-4 max-w-2xl text-[#657078]">{t('createTestHint', language)}</p></div>
      <form onSubmit={saveTest} className="grid gap-6">
        <div className="rounded-[28px] border-2 border-[#172026] bg-[#f9f4e9] p-6 shadow-[5px_6px_0_#172026] md:p-8">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-2 text-sm font-bold text-[#52606b]">{t('testTitle', language)}<input value={title} onChange={(event) => setTitle(event.target.value)} className="rounded-xl border border-[#d7cfbf] bg-[#fffaf2] px-4 py-3 outline-none focus:border-[#3155d8]" /></label>
            <label className="grid gap-2 text-sm font-bold text-[#52606b]">{t('testCategory', language)}<select value={category} onChange={(event) => setCategory(event.target.value as Exclude<Category, 'all'>)} className="rounded-xl border border-[#d7cfbf] bg-[#fffaf2] px-4 py-3 outline-none focus:border-[#3155d8]">{(['personal', 'geography', 'culture', 'science'] as const).map((key) => <option key={key} value={key}>{t(key, language)}</option>)}</select></label>
          </div>
          <label className="mt-4 grid gap-2 text-sm font-bold text-[#52606b]">{t('testDescription', language)}<textarea value={description} onChange={(event) => setDescription(event.target.value)} rows={3} className="rounded-xl border border-[#d7cfbf] bg-[#fffaf2] px-4 py-3 outline-none focus:border-[#3155d8]" /></label>
        </div>
        {questions.map((question, index) => <div key={index} className="rounded-[28px] border-2 border-[#172026] bg-[#f9f4e9] p-6 shadow-[5px_6px_0_#172026] md:p-8">
          <div className="mb-5 flex items-center justify-between gap-3"><h2 className="display text-3xl font-bold text-[#172026]">{t('questionPrompt', language)} {index + 1}</h2>{questions.length > 1 && <button type="button" onClick={() => setQuestions((current) => current.filter((_, questionIndex) => questionIndex !== index))} className="text-sm font-bold text-[#e96b4d] hover:underline">{t('removeQuestion', language)}</button>}</div>
          <label className="grid gap-2 text-sm font-bold text-[#52606b]">{t('questionPrompt', language)}<textarea value={question.prompt} onChange={(event) => updateQuestion(index, { prompt: event.target.value })} rows={2} className="rounded-xl border border-[#d7cfbf] bg-[#fffaf2] px-4 py-3 outline-none focus:border-[#3155d8]" /></label>
          <div className="mt-4 grid gap-3 md:grid-cols-2">{question.options.map((option, optionIndex) => <label key={optionIndex} className="grid gap-2 text-sm font-bold text-[#52606b]">{t('answerOption', language)} {String.fromCharCode(65 + optionIndex)}<input value={option} onChange={(event) => updateOption(index, optionIndex, event.target.value)} className="rounded-xl border border-[#d7cfbf] bg-[#fffaf2] px-4 py-3 outline-none focus:border-[#3155d8]" /></label>)}</div>
          <label className="mt-4 grid gap-2 text-sm font-bold text-[#52606b]">{t('correctOption', language)}<select value={question.answer} onChange={(event) => updateQuestion(index, { answer: Number(event.target.value) })} className="rounded-xl border border-[#d7cfbf] bg-[#fffaf2] px-4 py-3 outline-none focus:border-[#3155d8]">{question.options.map((_, optionIndex) => <option key={optionIndex} value={optionIndex}>{String.fromCharCode(65 + optionIndex)}</option>)}</select></label>
        </div>)}
        {error && <p className="rounded-xl bg-[#ffebe2] px-4 py-3 text-sm font-semibold text-[#b74431]">{error}</p>}
        <div className="flex flex-wrap gap-3"><button type="button" onClick={() => setQuestions((current) => current.length >= 10 ? current : [...current, { prompt: '', options: ['', '', '', ''], answer: 0 }])} className="rounded-full border-2 border-[#d7cfbf] px-5 py-3 text-sm font-bold text-[#52606b] hover:border-[#3155d8] hover:text-[#3155d8]">{t('addQuestion', language)}</button><button type="submit" className="primary-button inline-flex items-center gap-2 rounded-full bg-[#3155d8] px-5 py-3.5 text-sm font-bold text-white">{t('saveTest', language)} <ArrowRight size={17} /></button></div>
      </form>
    </div>
  </Shell>;
}

function TeacherResults({ language, setLanguage, user, onLogout }: { language: Language; setLanguage: (language: Language) => void; user?: User; onLogout: () => void }) {
  const results = readStorage<QuizResult[]>('quizly_results', []);
  if (!user || user.role !== 'teacher') return <Shell language={language} setLanguage={setLanguage} user={user} onLogout={onLogout}><div className="mx-auto max-w-xl px-5 py-32 text-center"><UsersRound className="mx-auto text-[#e96b4d]" size={40} /><h1 className="display mt-7 text-5xl font-bold">{t('teacherOnly', language)}</h1><Link href="/" className="primary-button mt-8 inline-flex rounded-full bg-[#3155d8] px-6 py-3.5 font-bold text-white">{t('home', language)}</Link></div></Shell>;
  return <Shell language={language} setLanguage={setLanguage} user={user} onLogout={onLogout}><div className="mx-auto max-w-6xl px-5 pb-24 pt-10 md:px-10 md:pt-20"><div className="mb-10 flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><p className="eyebrow text-[#e96b4d]">{t('teacherPanel', language)}</p><h1 className="display mt-3 text-5xl font-bold leading-[.95] text-[#172026]">{t('teacherResults', language)}</h1><p className="mt-4 text-[#657078]">{t('teacherPanelHint', language)}</p></div><Link href="/create-test" className="primary-button inline-flex items-center justify-center gap-2 rounded-full bg-[#3155d8] px-5 py-3.5 text-sm font-bold text-white"><BookOpen size={17} />{t('createTest', language)}</Link></div>{results.length === 0 ? <div className="rounded-[26px] border-2 border-dashed border-[#d7cfbf] bg-[#f8f2e7] px-6 py-20 text-center text-[#657078]">{t('noResults', language)}</div> : <div className="overflow-x-auto rounded-[24px] border-2 border-[#172026] bg-[#f9f4e9] shadow-[5px_6px_0_#172026]"><table className="w-full min-w-[680px] text-left text-sm"><thead className="bg-[#172026] text-[#f9f4e9]"><tr><th className="px-5 py-4">{t('studentColumn', language)}</th><th className="px-5 py-4">{t('quizColumn', language)}</th><th className="px-5 py-4">{t('scoreColumn', language)}</th><th className="px-5 py-4">{t('dateColumn', language)}</th></tr></thead><tbody>{results.map((result) => <tr key={result.id} className="border-t border-[#ded6c9]"><td className="px-5 py-4"><strong>{result.userName}</strong><span className="block text-xs text-[#7b817e]">{result.userEmail}</span></td><td className="px-5 py-4">{text(result.quizTitle, language)}</td><td className="px-5 py-4"><span className="rounded-full bg-[#d6ef4a] px-3 py-1 font-bold">{result.score}/{result.total} · {result.percentage}%</span></td><td className="px-5 py-4 text-[#7b817e]">{new Date(result.createdAt).toLocaleDateString(language === 'kk' ? 'kk-KZ' : language)}</td></tr>)}</tbody></table></div>}</div></Shell>;
}

function AppRoutes({ language, setLanguage }: { language: Language; setLanguage: (language: Language) => void }) {
  const [, setLocation] = useLocation();
  const [activeQuiz, setActiveQuiz] = useState<Quiz>();
  const [answers, setAnswers] = useState<Array<number | null>>([]);
  const [user, setUser] = useState<User | undefined>(() => readStorage<User | undefined>('quizly_current_user', undefined));

  function startQuiz(quiz: Quiz) {
    if (!user) {
      setLocation('/auth?mode=login');
      return;
    }
    setActiveQuiz(quiz);
    setAnswers(Array(quiz.questionsData.length).fill(null));
    setLocation('/play');
  }
  function finishQuiz() {
    if (activeQuiz && user) {
      const score = answers.reduce<number>((total, answer, index) => total + (answer === activeQuiz.questionsData[index]?.answer ? 1 : 0), 0);
      const result: QuizResult = { id: crypto.randomUUID(), userName: user.name, userEmail: user.email, quizId: activeQuiz.id, quizTitle: activeQuiz.title, score, total: activeQuiz.questionsData.length, percentage: Math.round((score / activeQuiz.questionsData.length) * 100), createdAt: new Date().toISOString() };
      const results = readStorage<QuizResult[]>('quizly_results', []);
      writeStorage('quizly_results', [result, ...results]);
    }
    setLocation('/results');
  }
  function restartQuiz() { if (!activeQuiz) return; setAnswers(Array(activeQuiz.questionsData.length).fill(null)); setLocation('/play'); }
  function logout() { window.localStorage.removeItem('quizly_current_user'); setUser(undefined); setLocation('/'); }

  return <Switch>
    <Route path="/"><Home language={language} user={user} onStart={startQuiz} onSetLanguage={setLanguage} onLogout={logout} /></Route>
    <Route path="/auth"><AuthView language={language} setLanguage={setLanguage} onAuth={setUser} onLogout={logout} user={user} /></Route>
    <Route path="/play"><Play quiz={activeQuiz} answers={answers} setAnswers={setAnswers} language={language} onFinish={finishQuiz} onHome={() => setLocation('/')} user={user} onLogout={logout} setLanguage={setLanguage} /></Route>
    <Route path="/results"><Results quiz={activeQuiz} answers={answers} language={language} user={user} onRestart={restartQuiz} onHome={() => setLocation('/')} onLogout={logout} setLanguage={setLanguage} /></Route>
    <Route path="/create-test"><CreateTest language={language} setLanguage={setLanguage} user={user} onLogout={logout} /></Route>
    <Route path="/teacher-results"><TeacherResults language={language} setLanguage={setLanguage} user={user} onLogout={logout} /></Route>
    <Route><Home language={language} user={user} onStart={startQuiz} onSetLanguage={setLanguage} onLogout={logout} /></Route>
  </Switch>;
}

function App() {
  const [language, setLanguage] = useState<Language>(() => readStorage<Language>('quizly_language', 'ru'));
  function changeLanguage(nextLanguage: Language) { setLanguage(nextLanguage); writeStorage('quizly_language', nextLanguage); }
  return <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><AppRoutes language={language} setLanguage={changeLanguage} /></WouterRouter>;
}

export default App;
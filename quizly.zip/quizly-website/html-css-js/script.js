const quizzes = [
  {
    id: "everyday",
    category: "personal",
    categoryLabel: "Для вас",
    color: "blue",
    icon: "✦",
    title: "Маленькие вопросы",
    description: "Пять неожиданных вопросов для разминки.",
    questions: [
      { text: "Какой орган человека считается самым большим?", options: ["Сердце", "Кожа", "Печень", "Лёгкие"], answer: 1, explanation: "Кожа — самый большой орган человеческого тела." },
      { text: "Сколько минут в одном часе?", options: ["30", "45", "60", "90"], answer: 2, explanation: "В одном часе 60 минут." },
      { text: "Какой цвет получится при смешивании синего и жёлтого?", options: ["Фиолетовый", "Зелёный", "Оранжевый", "Розовый"], answer: 1, explanation: "Синий и жёлтый дают зелёный цвет." },
    ],
  },
  {
    id: "geography",
    category: "geography",
    categoryLabel: "География",
    color: "coral",
    icon: "◎",
    title: "Мир вокруг",
    description: "Путешествие по карте без чемодана.",
    questions: [
      { text: "Какая страна по форме напоминает сапог?", options: ["Италия", "Чили", "Индия", "Норвегия"], answer: 0, explanation: "Италию часто сравнивают с сапогом." },
      { text: "Какой океан самый большой?", options: ["Атлантический", "Индийский", "Тихий", "Северный Ледовитый"], answer: 2, explanation: "Тихий океан занимает около трети поверхности Земли." },
      { text: "Столица Японии — это...", options: ["Киото", "Токио", "Осака", "Хиросима"], answer: 1, explanation: "Столица Японии — Токио." },
    ],
  },
  {
    id: "culture",
    category: "culture",
    categoryLabel: "Культура",
    color: "pink",
    icon: "▣",
    title: "Время культуры",
    description: "Искусство, книги, музыка и кино.",
    questions: [
      { text: "Кто написал роман «Война и мир»?", options: ["А. Чехов", "Л. Толстой", "Ф. Достоевский", "И. Тургенев"], answer: 1, explanation: "Автор романа — Лев Николаевич Толстой." },
      { text: "Как называется искусство складывания фигур из бумаги?", options: ["Оригами", "Граффити", "Каллиграфия", "Мозаика"], answer: 0, explanation: "Оригами — японское искусство складывания бумаги." },
      { text: "Сколько струн у классической скрипки?", options: ["3", "4", "5", "6"], answer: 1, explanation: "У классической скрипки четыре струны." },
    ],
  },
  {
    id: "science",
    category: "science",
    categoryLabel: "Наука",
    color: "teal",
    icon: "◇",
    title: "Любопытная наука",
    description: "Факты о природе, космосе и человеке.",
    questions: [
      { text: "Какая планета ближе всего к Солнцу?", options: ["Венера", "Марс", "Меркурий", "Земля"], answer: 2, explanation: "Меркурий — ближайшая к Солнцу планета." },
      { text: "Как называется процесс превращения воды в пар?", options: ["Замерзание", "Испарение", "Конденсация", "Плавление"], answer: 1, explanation: "Испарение — переход жидкости в газообразное состояние." },
      { text: "Сколько костей примерно в теле взрослого человека?", options: ["106", "206", "306", "406"], answer: 1, explanation: "У взрослого человека обычно 206 костей." },
    ],
  },
];

const state = {
  quiz: null,
  questionIndex: 0,
  score: 0,
  selected: null,
  seconds: 20,
  timerId: null,
};

const elements = {
  home: document.querySelector('[data-view="home"]'),
  quiz: document.querySelector('[data-view="quiz"]'),
  results: document.querySelector('[data-view="results"]'),
  grid: document.querySelector("[data-quiz-grid]"),
  question: document.querySelector("[data-question]"),
  answers: document.querySelector("[data-answers]"),
  counter: document.querySelector("[data-question-counter]"),
  progress: document.querySelector("[data-progress]"),
  timer: document.querySelector("[data-timer]"),
  next: document.querySelector("[data-next-question]"),
  explanation: document.querySelector("[data-explanation]"),
  score: document.querySelector("[data-score]"),
  resultsMessage: document.querySelector("[data-results-message]"),
};

function renderCards(category = "all") {
  const visibleQuizzes = quizzes.filter((quiz) => category === "all" || quiz.category === category);
  elements.grid.innerHTML = visibleQuizzes.map((quiz) => `
    <article class="quiz-card" data-color="${quiz.color}">
      <div class="quiz-card-top">
        <span class="quiz-icon">${quiz.icon}</span>
        <span class="quiz-category">${quiz.categoryLabel}</span>
      </div>
      <div class="quiz-card-content">
        <h3>${quiz.title}</h3>
        <p>${quiz.description}</p>
        <button type="button" data-start-quiz="${quiz.id}">Начать викторину →</button>
      </div>
    </article>
  `).join("");
}

function showView(name) {
  [elements.home, elements.quiz, elements.results].forEach((view) => view.classList.add("hidden"));
  document.querySelector(`[data-view="${name}"]`).classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function startQuiz(id) {
  state.quiz = quizzes.find((quiz) => quiz.id === id);
  state.questionIndex = 0;
  state.score = 0;
  showView("quiz");
  renderQuestion();
}

function renderQuestion() {
  const question = state.quiz.questions[state.questionIndex];
  state.selected = null;
  state.seconds = 20;
  clearInterval(state.timerId);
  elements.counter.textContent = `Вопрос ${state.questionIndex + 1} из ${state.quiz.questions.length}`;
  elements.progress.style.width = `${((state.questionIndex + 1) / state.quiz.questions.length) * 100}%`;
  elements.question.textContent = question.text;
  elements.answers.innerHTML = question.options.map((option, index) => `
    <button class="answer-button" type="button" data-answer="${index}">${option}</button>
  `).join("");
  elements.next.disabled = true;
  elements.next.textContent = "Ответить";
  elements.explanation.classList.add("hidden");
  elements.explanation.textContent = "";
  updateTimer();
  state.timerId = setInterval(() => {
    state.seconds -= 1;
    updateTimer();
    if (state.seconds <= 0) {
      clearInterval(state.timerId);
      chooseAnswer(null);
    }
  }, 1000);
}

function updateTimer() {
  elements.timer.textContent = `00:${String(state.seconds).padStart(2, "0")}`;
}

function chooseAnswer(index) {
  if (state.selected !== null) return;
  clearInterval(state.timerId);
  state.selected = index;
  const question = state.quiz.questions[state.questionIndex];
  const buttons = [...elements.answers.querySelectorAll(".answer-button")];
  buttons.forEach((button, buttonIndex) => {
    button.disabled = true;
    if (buttonIndex === question.answer) button.classList.add("correct");
    if (buttonIndex === index && index !== question.answer) button.classList.add("wrong");
  });
  if (index === question.answer) state.score += 1;
  elements.explanation.textContent = index === question.answer
    ? `Верно! ${question.explanation}`
    : `Правильный ответ: ${question.options[question.answer]}. ${question.explanation}`;
  elements.explanation.classList.remove("hidden");
  elements.next.disabled = false;
  elements.next.textContent = state.questionIndex === state.quiz.questions.length - 1 ? "Узнать результат" : "Следующий вопрос";
}

function nextQuestion() {
  if (state.selected === null) return;
  if (state.questionIndex === state.quiz.questions.length - 1) {
    showResults();
    return;
  }
  state.questionIndex += 1;
  renderQuestion();
}

function showResults() {
  clearInterval(state.timerId);
  const percentage = Math.round((state.score / state.quiz.questions.length) * 100);
  elements.score.textContent = percentage;
  elements.resultsMessage.textContent = percentage === 100
    ? "Идеальный результат. Кажется, ваш мозг сегодня в отличной форме."
    : percentage >= 60
      ? "Хороший раунд! Ещё одна попытка — и будет новый личный рекорд."
      : "Любопытство уже победа. Попробуйте другую тему и сыграйте ещё раз.";
  showView("results");
}

document.addEventListener("click", (event) => {
  const startButton = event.target.closest("[data-start-quiz]");
  const answerButton = event.target.closest("[data-answer]");
  const filterButton = event.target.closest("[data-category]");

  if (startButton) startQuiz(startButton.dataset.startQuiz);
  if (answerButton) chooseAnswer(Number(answerButton.dataset.answer));
  if (filterButton) {
    document.querySelectorAll(".filter-button").forEach((button) => button.classList.remove("active"));
    filterButton.classList.add("active");
    renderCards(filterButton.dataset.category);
  }
});

document.querySelectorAll("[data-back-home], [data-home-link]").forEach((button) => {
  button.addEventListener("click", (event) => {
    event.preventDefault();
    clearInterval(state.timerId);
    showView("home");
  });
});

document.querySelector("[data-next-question]").addEventListener("click", nextQuestion);
document.querySelector("[data-restart]").addEventListener("click", () => startQuiz(state.quiz.id));

renderCards();